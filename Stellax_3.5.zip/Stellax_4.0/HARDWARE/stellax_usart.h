#include "usart.h"
int rx_data(void);
void send_data(void);
