#ifndef __DELAY1__H
#define __DELAY1__H
#include "sys.h"

void delay_us(u16 i);
void delay_ms(u16 i);

#endif
